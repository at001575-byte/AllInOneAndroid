package com.example.allinone

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.os.StatFs
import android.os.Environment
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(5, 13, 29)
    private val panel = Color.rgb(15, 29, 49)
    private val blue = Color.rgb(0, 155, 255)
    private val white = Color.WHITE
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        home()
    }
    private fun text(s: String, size: Float, color: Int = white): TextView =
        TextView(this).apply { text=s; textSize=size; setTextColor(color); setPadding(0,8,0,8) }
    private fun button(label: String, action: () -> Unit): Button =
        Button(this).apply { text=label; setOnClickListener { action() } }
    private fun setup(title: String) {
        root = LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL; setPadding(22,28,22,20); setBackgroundColor(bg)
        }
        val scroller = ScrollView(this).apply { addView(root) }
        setContentView(scroller)
        root.addView(text("🚀  $title", 28f))
        root.addView(text("Smart • Fast • Safe • Complete", 14f, Color.LTGRAY))
    }
    private fun card(title: String, desc: String, action: () -> Unit) {
        val box = LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL; setPadding(16,12,16,12); setBackgroundColor(panel)
        }
        box.addView(text(title,20f))
        box.addView(text(desc,14f,Color.LTGRAY))
        box.addView(button("OPEN", action))
        val lp=LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,12,0,0)
        root.addView(box,lp)
    }
    private fun home() {
        setup("All in One")
        root.addView(text("Your everyday phone toolkit",17f,Color.CYAN))
        card("📊  Device Monitor","Check storage and Android device information") { monitor() }
        card("🧹  App Cache","Android does not allow apps to silently clear other apps' cache. Open system settings instead.") { openStorageSettings() }
        card("🔐  Security","Open Android security and privacy settings") { openSecuritySettings() }
        card("⚡  Performance Tips","Practical settings for smoother performance") { tips() }
        card("🤖  AI Assistant","Open ChatGPT in your browser") { openUrl("https://chatgpt.com") }
        card("🧰  Useful Tools","Battery settings, app settings and network settings") { tools() }
        root.addView(text("Privacy-first: no account, ads, or data collection in this starter app.",12f,Color.GRAY))
    }
    private fun monitor() {
        setup("Device Monitor")
        val stat = StatFs(Environment.getDataDirectory().path)
        val total = stat.totalBytes / (1024L*1024*1024)
        val free = stat.availableBytes / (1024L*1024*1024)
        root.addView(text("Internal storage",20f))
        root.addView(text("Approx. total: $total GB\nAvailable: $free GB\nUsed: ${total-free} GB",18f,Color.CYAN))
        root.addView(text("Device model: ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}\nAndroid: ${android.os.Build.VERSION.RELEASE} (API ${android.os.Build.VERSION.SDK_INT})",16f))
        root.addView(text("Note: Android limits third-party access to detailed CPU temperature, RAM control and other apps' process data.",14f,Color.LTGRAY))
        root.addView(button("BACK") { home() })
    }
    private fun tools() {
        setup("Useful Tools")
        card("Battery settings","View battery usage and battery controls") { openSettings("android.settings.BATTERY_SAVER_SETTINGS") }
        card("App management","Review installed apps and permissions") { openSettings("android.settings.APPLICATION_SETTINGS") }
        card("Network settings","Open Wi-Fi and network controls") { openSettings("android.settings.WIRELESS_SETTINGS") }
        card("Storage settings","Review storage and free space") { openStorageSettings() }
        root.addView(button("BACK") { home() })
    }
    private fun tips() {
        setup("Performance Tips")
        listOf("Restart the phone if it has been running for many days.",
            "Keep at least 10–15% of storage free.",
            "Uninstall or restrict apps you do not use.",
            "Update Android and apps from trusted sources.",
            "Check Settings → Battery for apps draining power.",
            "Avoid 'RAM booster' apps that repeatedly kill background apps; Android manages memory itself.",
            "If the phone overheats, pause heavy gaming and let it cool naturally.").forEach { root.addView(text("• $it",17f)) }
        root.addView(button("BACK") { home() })
    }
    private fun openStorageSettings() = openSettings("android.settings.INTERNAL_STORAGE_SETTINGS")
    private fun openSecuritySettings() = openSettings("android.settings.SECURITY_SETTINGS")
    private fun openSettings(action: String) {
        try { startActivity(Intent(action)) } catch (_: Exception) {
            try { startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)) } catch (_: Exception) {}
        }
    }
    private fun openUrl(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) {}
    }
}
