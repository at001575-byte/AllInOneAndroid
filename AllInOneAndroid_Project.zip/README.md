# All in One Android starter app

This is a native Kotlin Android Studio project for a simple phone-tool dashboard.

## Build an APK
1. Install Android Studio on a computer.
2. Open this folder (`AllInOneAndroid`) as a project.
3. Allow Gradle sync and install the Android SDK platform requested by the project (API 35).
4. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will show the generated APK path (usually `app/build/outputs/apk/debug/app-debug.apk`).

## What works
- Device model / Android version / approximate internal storage display.
- Short performance tips.
- Links to Android settings for storage, security, battery, apps, and network.
- Opens ChatGPT in a browser.

## Important limits
This starter does not claim to magically boost CPU/RAM, read private data from other apps, or silently clean other apps' cache. Android restricts those actions for normal apps. Detailed temperature readings and antivirus-grade scanning need additional supported APIs/permissions and careful implementation.

No network permission is requested by this app; the AI button opens ChatGPT externally.
